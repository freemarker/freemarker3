HTML+FTL syntax file for TextPad 4.
Author: Dave Benjamin

Put ftl.syn in "Program Files\TextPad 4\System". Then, go to 
"Configure->New Document Class" in TextPad. Call the new class 
"FreeMarker", and on the next page, type "*.ftl" as the wildcard. On the 
last page, enable syntax highlighting and choose "ftl.syn" as the syntax 
definition file. If you want FTL constructs to be a different color, go to 
"Configure->Preferences" and set the foreground for "Keywords 3".

Enjoy!